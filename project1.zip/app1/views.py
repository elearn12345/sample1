from django.shortcuts import render, redirect
from app1.models import Employee
from app1.forms import EmployeeForm
from django.http import HttpResponse


# Create your views here.

def homeview(request):
	emp=Employee.objects.all()
	return render(request,'app1/home.html',{'e':emp})

def aboutview(request):
	return render(request,'app1/about.html')

def servicesview(request):
	return render(request,'app1/services.html')

def thanksview(request):
	return HttpResponse('<h1>Successfully sent</h1>')

def contactview(request):
	f=EmployeeForm()
	if request.method=='POST':
		form=EmployeeForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('/home')

	return render(request,'app1/contact.html',{'form':f})